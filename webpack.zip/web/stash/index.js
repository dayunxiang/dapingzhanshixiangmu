import Vue from 'vue'
import VueStash from 'vue-stash';
Vue.use(VueStash);
export const store = {
    GBindings:{}
}