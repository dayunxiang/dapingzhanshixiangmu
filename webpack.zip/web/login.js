import Vue from 'vue'
import App from './LoginPage'
import $ from 'jquery';
debugger
Vue.config.productionTip = false
new Vue({
  el: '#app',
  template: '<App/>',
  components: {
    App
  }
})